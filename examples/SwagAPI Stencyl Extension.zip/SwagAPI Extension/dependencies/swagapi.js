/*
<script type="text/javascript" src="https://swagapi.shockwave.com/dist/swag-api.js"></script>   
<link rel="stylesheet" type="text/css" href="https://swagapi.shockwave.com/dist/swag-api.css"></link>
*/

var loadSWAG = function(implementationCode){
    //url is URL of external file, implementationCode is the code
    //to be called from the file, location is the location to 
    //insert the <script> element
	var head = document.head;

    var scriptTag = document.createElement('script');
    scriptTag.src = 'https://swagapi.shockwave.com/dist/swag-api.js';
    scriptTag.onload = implementationCode;
    scriptTag.onreadystatechange = implementationCode;
    head.appendChild(scriptTag);

	var link = document.createElement('link'); 
	link.rel = 'stylesheet';  
	link.type = 'text/css'; 
	link.href = 'https://swagapi.shockwave.com/dist/swag-api.css';  

	// Append link element to HTML head 
	head.appendChild(link);  
};

var yourCodeToBeCalled = function(){
	console.log ("loaded");
}
loadSWAG(yourCodeToBeCalled);

function Initialize(gameAPI) {
	console.log ("Initialize: ", gameAPI);
    var game = document.getElementById("openfl-content");
	
	console.log ("game:" + game);
	
	if (game)
	{
		document.swagapi = SWAGAPI.getInstance({
				wrapper: game,
				api_key: gameAPI,        // need to change
				theme: 'shockwave',
				debug: true
			});
	}
}

function startSession (){
	console.log ("startSession");
	
	if (document.swagapi)
	{
		document.swagapi.startSession ()
			.then (function (){
				var user = document.swagapi.getCurrentEntity ();
				console.log (user);
				
				return 1
			});
	}
}

function showLeaderboard (type){
	console.log ("showLeaderboard");
	
	if (document.swagapi)
	{
		document.swagapi.showDialog (type, { title: "Best Score" })
			.then (function (){
			});
	}
}

function postDailyScore (levelKey, score){
	console.log ("postDailyScore:", levelKey, score);
	
	if (document.swagapi)
	{
		document.swagapi.postScore (levelKey, score);
	}
}
